# 競輪分析AI

GitHub Pages公開用ファイルです。

## 公開手順
1. GitHubで新しいRepositoryを作成（例: `keirin-ai`）
2. このフォルダ内の `index.html` をRepositoryのルートにアップロード
3. Settings → Pages
4. Sourceを `Deploy from a branch`
5. Branchを `main` / `/ (root)` にしてSave
6. 数分後に表示されたURLをiPhoneのSafariで開く

## 注意
WINTICKETの非公開APIを解析・スクレイピングして自動取得する機能は含めていません。
許可されたAPI/データ提供元を接続する場合は、既存のAPIエンドポイント部分を利用してください。
